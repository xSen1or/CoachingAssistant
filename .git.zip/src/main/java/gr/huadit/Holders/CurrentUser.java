package gr.huadit.Holders;

import org.json.JSONObject;

/*
    DTO Class that holds the current user.
*/

public class CurrentUser {
    public static JSONObject currentUser;
}
