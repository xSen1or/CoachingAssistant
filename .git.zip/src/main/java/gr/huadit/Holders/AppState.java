package gr.huadit.Holders;

/*
    DTO Class for the calorie calculator
*/

public class AppState {
    public static int dailyGoal = 0;
    public static int todayConsumed = 0;
}
