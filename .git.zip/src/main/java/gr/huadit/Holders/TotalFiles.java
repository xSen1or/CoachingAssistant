package gr.huadit.Holders;
import java.util.ArrayList;
import java.util.List;

/*
    DTO Class that holds the selected files.
*/

public class TotalFiles {
    public static List<String> results = new ArrayList<>();
}
