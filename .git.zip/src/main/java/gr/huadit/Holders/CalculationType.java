package gr.huadit.Holders;

public class CalculationType {
    public static String calculationType;
}
