package gr.huadit.Interfaces;
import gr.huadit.Enums.LoggerLevel;


public interface Logger {

    void print(String message, LoggerLevel l);

}
